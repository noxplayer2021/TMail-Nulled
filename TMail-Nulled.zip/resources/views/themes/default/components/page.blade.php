<main class="page p-5">
    {!! $page->content !!}
</main>
