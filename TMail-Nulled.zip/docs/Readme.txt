You can use Documentation.pdf incase you are not familar with the process. 
Here is the installation video - https://www.youtube.com/watch?v=QcIeTlGNJqo